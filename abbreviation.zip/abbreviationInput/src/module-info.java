module abbreviationInput {
}