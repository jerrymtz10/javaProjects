package abbreviationInput;
import java.util.Scanner;


public class abbreviation {
	public static void main(String[] args) {
		
		String BFF = "Best Friend Forever";
		String IMHO = "IN My Humble Opinion";
		String TMI = "Too Much Information";
		String LOL = "Laughing Out Loud";
		String IDK = "I Don't Know";
		
		Scanner scnr = new Scanner(System.in);
		
		String textMsg = "";
		
		System.out.println("Input an name" + "");
		
		textMsg = scnr.nextLine();
		
		if (textMsg.compareTo("BFF")==0)
		{
			System.out.println(BFF);
		}
		else if(textMsg.compareTo("IMHO")==0)
		{
			System.out.println(IMHO);
		}
		else if(textMsg.compareTo("TMI")==0)
		{
			System.out.println(TMI);
		}
		else if(textMsg.compareTo("LOL")==0)
		{
			System.out.println(LOL);
		}
		else if(textMsg.compareTo("IDK")==0)
		{
			System.out.println(IDK);
		}
		else {
			System.out.print("Unknown");
		}
		
		return;
		
	}

}
