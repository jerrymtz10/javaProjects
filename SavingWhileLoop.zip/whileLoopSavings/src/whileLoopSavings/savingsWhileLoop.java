package whileLoopSavings;

import java.util.Scanner;

public class savingsWhileLoop {
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		final int INIT_SAVINGS = 10000; 			//initial saving starting off with
		final double INTEREST_RATE = 0.5; 			// 5% year interest 
		int userYears = 0; 							//user input number of years
		int i = 0;				 					//loop variable 
		double currSavings = 0.0; 					//Saving with interest
		
		System.out.println("Intitial saving of $" + INIT_SAVINGS); 
		System.out.println("at " + INTEREST_RATE + "yearls interest.\n");
		
		
		System.out.print("Enter years: ");
		userYears = scnr.nextInt();
		
		currSavings = 	INIT_SAVINGS; 
		i = 1; 
		while (i <= userYears) {
			System.out.println(" Savings in years " + 1 + ": $" + currSavings);
			
			currSavings = currSavings + (currSavings * INTEREST_RATE);
			
			i = i + 1;
			
		}
			System.out.println();
			
			return;
		
	}

}
