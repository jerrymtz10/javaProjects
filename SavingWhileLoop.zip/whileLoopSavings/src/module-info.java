import java.util.Scanner;


module whileLoopSavings {
}