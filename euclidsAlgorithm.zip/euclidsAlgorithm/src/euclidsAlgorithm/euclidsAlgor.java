package euclidsAlgorithm;
import java.util.Scanner;


public class euclidsAlgor {
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		int numA = 0; //user input for numA
		int numB = 0; //user input for numB
		
		System.out.print("Enter first positive integer: ");
		numA = scnr.nextInt();
		
		System.out.print("Enter second positive integerL: ");
		numB = scnr.nextInt();
		
		while(numA != numB)	//Euclid's Algorithm 
			if(numB > numA) {
				numB = numB - numA;			
			}
			else {
				numA = numA - numB;	
			}
	
			System.out.println("GCD is: " + numA);
		
		return;
}
}
