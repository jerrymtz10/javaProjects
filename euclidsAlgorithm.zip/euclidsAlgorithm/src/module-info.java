module euclidsAlgorithm {
}