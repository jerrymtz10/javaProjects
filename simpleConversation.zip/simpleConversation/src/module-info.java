module simpleConversation {
}